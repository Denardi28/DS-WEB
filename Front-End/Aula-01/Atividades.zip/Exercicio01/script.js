var nome1 = prompt("Digite seu nome: ");

var nome2 = prompt("Digite seu sobrenome: ");

console.log(nome1 + " " + nome2);