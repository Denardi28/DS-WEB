var fah = prompt("Digite a temperatura em F°: ");

var resultado = (fah - 32) * 0.5556;

alert("C° " + resultado);
console.log("C° " + resultado);