var num = prompt("Digite um número: ");

var resultado = num * num * num;

console.log("O resultado é igual a: " + resultado);