var num1 = Number(prompt("Digite o 1º Numero: "));

var num2 = Number(prompt("Digite o 2º Numero: "));

var soma = num1 + num2;

alert(soma);

var num3 = Number(prompt("Digite o 1º Numero: "));

var num4 = Number(prompt("Digite o 2º Numero: "));

var sub = num3 - num4;

alert(sub);

var num5 = Number(prompt("Digite o 1º Numero: "));

var num6 = Number(prompt("Digite o 2º Numero: "));

var div = num5 / num6;

alert(div);

var num7 = Number(prompt("Digite o 1º Numero: "));

var num8 = Number(prompt("Digite o 2º Numero: "));

var mul = num7 * num8;

alert(mul);

console.log(soma);
console.log(sub);
console.log(div);
console.log(mul);




